require 'watir/generator/base'
require 'watir/generator/html'
require 'watir/generator/svg'
