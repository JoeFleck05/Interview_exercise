module Watir
  class TextArea < HTMLElement
    include UserEditable
  end # TextArea
end # Watir
