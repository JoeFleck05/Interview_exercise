module Watir
  module Locators
    class Button
      class SelectorBuilder < Element::SelectorBuilder
      end
    end
  end
end
