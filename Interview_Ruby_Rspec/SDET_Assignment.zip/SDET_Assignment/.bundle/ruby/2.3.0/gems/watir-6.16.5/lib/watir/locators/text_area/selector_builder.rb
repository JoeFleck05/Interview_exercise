module Watir
  module Locators
    class TextArea
      class SelectorBuilder < Element::SelectorBuilder
      end
    end
  end
end
