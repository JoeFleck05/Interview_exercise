require 'watir'
warn Kernel.caller.first + ': `require "watir-webdriver"` is deprecated. Please, use `require "watir"`.'
