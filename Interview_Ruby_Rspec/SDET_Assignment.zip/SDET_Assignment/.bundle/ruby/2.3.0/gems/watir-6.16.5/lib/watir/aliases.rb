module Watir
  module Container
    alias field_set fieldset
    alias field_sets fieldsets
  end # Container
end # Watir
