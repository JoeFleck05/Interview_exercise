module Watir
  VERSION = '6.16.5'.freeze
end
