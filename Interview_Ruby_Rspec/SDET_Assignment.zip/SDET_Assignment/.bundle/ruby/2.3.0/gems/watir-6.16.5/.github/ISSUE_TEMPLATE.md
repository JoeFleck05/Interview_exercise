## Meta -
Watir Version: 
Selenium Version: 
Browser Version: 
Browser Driver Version: 
OS Version: 

## Expected Behavior -

## Actual Behavior -

## Steps to reproduce -
<!--
Please be sure to include an SSCCE (Short, Self Contained, Correct [compilable] example) http://sscce.org/
If you can't provide a link to the page, consider creating a reproducible page on https://jsfiddle.net/
-->
