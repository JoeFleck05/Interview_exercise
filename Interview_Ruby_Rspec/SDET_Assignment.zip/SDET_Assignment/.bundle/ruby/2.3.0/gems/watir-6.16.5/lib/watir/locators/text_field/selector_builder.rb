module Watir
  module Locators
    class TextField
      class SelectorBuilder < Element::SelectorBuilder
      end
    end
  end
end
