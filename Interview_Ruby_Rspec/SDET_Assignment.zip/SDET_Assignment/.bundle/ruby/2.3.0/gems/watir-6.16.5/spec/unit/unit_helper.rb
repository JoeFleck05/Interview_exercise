require 'watirspec'
WatirSpec::Runner.execute = false

require_relative '../watirspec_helper'
